create table orderdetails(id integer,custid integer,amount double,state VARCHAR(20),primary key(id));
