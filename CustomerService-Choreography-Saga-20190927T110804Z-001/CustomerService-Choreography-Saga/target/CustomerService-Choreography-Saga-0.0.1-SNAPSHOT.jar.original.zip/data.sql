insert into customer values(1,1000);
insert into customer values(2,500);