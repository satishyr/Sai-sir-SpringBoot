create table item(id integer primary key,name varchar(20),qty integer);
insert into item values(1,'item1',4);
insert into item values(2,'item2',6);